package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.Client;
import util.DbUtil;

public class ClientDao implements Dao {

    private Connection connection;

    public ClientDao() {
    	
        try {
			connection = DbUtil.getConnection();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ArithmeticException("ClientDao: DB Connect: " + e.getMessage());
		}
    
    } //ClientDao

    public void addClient(Client client) {
        
    	try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("INSERT INTO CLIENT (NAME, EMAIL) VALUES (?, ?)");
            
            // Parameters start with 1
            preparedStatement.setString(1, client.getName());
            preparedStatement.setString(2, client.getEmail());

            
            preparedStatement.executeUpdate();
            

        } catch (SQLException e) {
            e.printStackTrace();
            
            throw new ArithmeticException("ClientDao: addClient: " + e.getMessage()); 
        }
    } //addPClient

    public void deleteClient(long id) {
        try {
            
        	PreparedStatement preparedStatement = connection
                    .prepareStatement("DELETE FROM CLIENT WHERE ID=?");
            
            // Parameters start with 1
            preparedStatement.setLong(1, id);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    } //deleteClient

    public void updateClient(Client client) {
        try {
            PreparedStatement preparedStatement = connection
                    .prepareStatement("UPDATE USERS SET NAME=?, " + "EMAIL=? " + "WHERE ID=?");
            
            // Parameters start with 1
            preparedStatement.setString(1, client.getName());
            preparedStatement.setString(2, client.getEmail());           
            preparedStatement.setLong(3, client.getId());
            
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    } //updateClient
	
    public List<Client> getAllClient() {
        
    	List<Client> c = new ArrayList<Client>();
        
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery("SELECT * FROM CLIENT");
            while (rs.next()) {
                
            	Client client = new Client();
                
            	client.setId(rs.getLong("ID"));
                client.setName(rs.getString("NAME"));
                client.setEmail(rs.getString("EMAIL"));

                c.add(client);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return c;
    } //getAllClient

    public Client getUserById(long id) {

    	Client c = new Client();
        
    	try {
            PreparedStatement preparedStatement = connection.
                    prepareStatement("SELECT * from CLIENT WHERE ID=?");
            
            preparedStatement.setLong(1, id);
            ResultSet rs = preparedStatement.executeQuery();

            if (rs.next()) {
                c.setId(rs.getLong("ID"));
                c.setName(rs.getString("NAME"));
                c.setEmail(rs.getString("EMAIL"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return c;
    } //getUserById
    
}