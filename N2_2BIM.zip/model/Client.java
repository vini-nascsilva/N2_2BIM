package model;

//JavaBean - POJO


import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Client implements Serializable  {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	long id;
	
	String name,
	       email;
	
	public Client(Long id, String name, String email) {
		
		super();
		this.setId(id);
		this.setName(name);
		this.setEmail(email);
	}

	public Client(String id, String name, String email) {
		
		super();
		this.setId(id);
		this.setName(name);
		this.setEmail(email);
	}

	public Client() { //Default constructor
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return this.id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public void setId(String id) {
		if (id != null)
		   this.id = Long.valueOf(id);
		else
		   this.id = 0;
	}	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
		
	@Override
	public boolean equals(Object obj) {
		
		if(obj != null && obj instanceof Client) {

            return (this.getId() == ((Client) obj).getId());

        }  else {
        	
            return false;

        } //if

	} //equals
	
	@Override
    public String toString() {
        return "Client ["
                + "  id=" + this.id 
        		+ ", name=" + this.name
                + ", email=" + this.email 
                + "]";
    }    	
} 
